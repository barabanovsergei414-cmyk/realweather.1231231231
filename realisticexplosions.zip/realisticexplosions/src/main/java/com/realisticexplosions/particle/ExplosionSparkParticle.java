package com.realisticexplosions.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.*;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ExplosionSparkParticle extends TextureSheetParticle {

    private ExplosionSparkParticle(ClientLevel level, double x, double y, double z,
                                    double vx, double vy, double vz) {
        super(level, x, y, z, vx, vy, vz);

        // Ярко-оранжевые/жёлтые искры
        this.rCol = 1.0f;
        this.gCol = 0.5f + (float)(random.nextDouble() * 0.4);
        this.bCol = 0.0f;
        this.alpha = 1.0f;

        this.lifetime = 15 + random.nextInt(20);
        this.quadSize = 0.05f + (float)(random.nextDouble() * 0.08);
        this.gravity = 0.12f;

        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
    }

    @Override
    public void tick() {
        super.tick();
        // Трение
        this.xd *= 0.95f;
        this.zd *= 0.95f;
        // Гаснет к концу жизни
        float lifeRatio = 1.0f - (float)this.age / this.lifetime;
        this.alpha = lifeRatio * lifeRatio;
        // Цвет от белого к оранжевому к красному
        this.rCol = 1.0f;
        this.gCol = lifeRatio * 0.6f;
        this.bCol = lifeRatio > 0.5f ? (lifeRatio - 0.5f) * 0.3f : 0;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @OnlyIn(Dist.CLIENT)
    public static class Factory implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Factory(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level,
                                        double x, double y, double z,
                                        double vx, double vy, double vz) {
            ExplosionSparkParticle p = new ExplosionSparkParticle(level, x, y, z, vx, vy, vz);
            p.pickSprite(sprites);
            return p;
        }
    }
}
