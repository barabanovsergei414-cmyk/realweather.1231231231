package com.realisticexplosions.client;

import com.realisticexplosions.particle.ExplosionParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class ExplosionEffectClient {

    // Список отложенных звуков (задержка по расстоянию)
    private static final List<DelayedSound> DELAYED_SOUNDS = new ArrayList<>();
    // Текущий shake
    public static float shakePower = 0;
    public static float shakeX = 0;
    public static float shakeY = 0;
    // Текущая вспышка
    public static float flashAlpha = 0;
    // Ударная волна
    public static final List<ShockwaveRing> SHOCKWAVES = new ArrayList<>();

    private static final Random RNG = new Random();

    public static void triggerEffect(Vec3 center, float power, float normalizedPower,
                                      float distToPlayer, int soundDelayTicks) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) return;

        // 1. ВСПЫШКА — мгновенно
        flashAlpha = Math.min(1.0f, 0.4f + 0.6f * normalizedPower * (1.0f - distToPlayer / 64.0f));
        flashAlpha = Math.max(0, flashAlpha);

        // 2. ТРЯСКА — мгновенно, сила зависит от расстояния
        float shakeStrength = normalizedPower * Math.max(0, 1.0f - distToPlayer / 32.0f);
        shakePower = Math.max(shakePower, shakeStrength * 5.0f);

        // 3. УДАРНАЯ ВОЛНА — видимое кольцо
        SHOCKWAVES.add(new ShockwaveRing(center, normalizedPower));

        // 4. ЧАСТИЦЫ — пыль и искры
        spawnParticles(mc, center, normalizedPower, power);

        // 5. ОТЛОЖЕННЫЙ ЗВУК
        DELAYED_SOUNDS.add(new DelayedSound(center, power, normalizedPower, soundDelayTicks));
    }

    private static void spawnParticles(Minecraft mc, Vec3 center, float normalizedPower, float power) {
        int dustCount = (int)(80 * normalizedPower);
        int sparkCount = (int)(50 * normalizedPower);
        int smokeCount = (int)(40 * normalizedPower);

        // Пыль
        for (int i = 0; i < dustCount; i++) {
            double vx = (RNG.nextDouble() - 0.5) * 1.5 * normalizedPower;
            double vy = RNG.nextDouble() * 1.2 * normalizedPower + 0.2;
            double vz = (RNG.nextDouble() - 0.5) * 1.5 * normalizedPower;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_DUST.get(),
                center.x + (RNG.nextDouble()-0.5)*2,
                center.y + (RNG.nextDouble())*1.5,
                center.z + (RNG.nextDouble()-0.5)*2,
                vx, vy, vz);
        }

        // Искры
        for (int i = 0; i < sparkCount; i++) {
            double vx = (RNG.nextDouble() - 0.5) * 2.5 * normalizedPower;
            double vy = RNG.nextDouble() * 2.0 * normalizedPower;
            double vz = (RNG.nextDouble() - 0.5) * 2.5 * normalizedPower;
            mc.level.addParticle(ExplosionParticles.EXPLOSION_SPARK.get(),
                center.x, center.y + 0.5, center.z,
                vx, vy, vz);
        }

        // Дым
        for (int i = 0; i < smokeCount; i++) {
            double vx = (RNG.nextDouble() - 0.5) * 0.5;
            double vy = RNG.nextDouble() * 0.8 + 0.1;
            double vz = (RNG.nextDouble() - 0.5) * 0.5;
            mc.level.addParticle(net.minecraft.core.particles.ParticleTypes.LARGE_SMOKE,
                center.x + (RNG.nextDouble()-0.5)*power,
                center.y + (RNG.nextDouble())*power*0.5,
                center.z + (RNG.nextDouble()-0.5)*power,
                vx, vy, vz);
        }
    }

    // Вызывается каждый тик из ClientTickHandler
    public static void tick() {
        // Уменьшаем тряску
        if (shakePower > 0) {
            shakeX = (float)(RNG.nextGaussian() * shakePower);
            shakeY = (float)(RNG.nextGaussian() * shakePower);
            shakePower *= 0.75f;
            if (shakePower < 0.01f) { shakePower = 0; shakeX = 0; shakeY = 0; }
        }

        // Уменьшаем вспышку
        if (flashAlpha > 0) {
            flashAlpha *= 0.80f;
            if (flashAlpha < 0.01f) flashAlpha = 0;
        }

        // Обновляем ударные волны
        Iterator<ShockwaveRing> sw = SHOCKWAVES.iterator();
        while (sw.hasNext()) {
            ShockwaveRing ring = sw.next();
            ring.tick();
            if (ring.isDead()) sw.remove();
        }

        // Проигрываем отложенные звуки
        Minecraft mc = Minecraft.getInstance();
        Iterator<DelayedSound> it = DELAYED_SOUNDS.iterator();
        while (it.hasNext()) {
            DelayedSound ds = it.next();
            ds.ticksLeft--;
            if (ds.ticksLeft <= 0) {
                playExplosionSound(mc, ds);
                it.remove();
            }
        }
    }

    private static void playExplosionSound(Minecraft mc, DelayedSound ds) {
        if (mc.level == null || mc.player == null) return;

        // Громкость зависит от мощности, дистанция уже учтена в позиции
        float volume = Math.min(4.0f, ds.normalizedPower * 2.5f);
        float pitch = 0.8f + RNG.nextFloat() * 0.3f;

        // Используем стандартный звук взрыва — он уже есть в MC
        mc.level.playLocalSound(
            ds.center.x, ds.center.y, ds.center.z,
            SoundEvents.GENERIC_EXPLODE,
            SoundSource.BLOCKS,
            volume, pitch, false
        );

        // Дополнительный глубокий бас при большом взрыве
        if (ds.normalizedPower > 1.5f) {
            mc.level.playLocalSound(
                ds.center.x, ds.center.y, ds.center.z,
                SoundEvents.GENERIC_EXPLODE,
                SoundSource.BLOCKS,
                volume * 0.6f, 0.5f, false
            );
        }
    }

    // --- Вложенные классы ---

    public static class ShockwaveRing {
        public final Vec3 center;
        public final float maxRadius;
        public float radius = 0;
        public float alpha = 1.0f;
        private int age = 0;
        private static final int LIFETIME = 25; // тиков

        public ShockwaveRing(Vec3 center, float normalizedPower) {
            this.center = center;
            this.maxRadius = 6.0f + 10.0f * normalizedPower;
        }

        public void tick() {
            age++;
            float t = (float) age / LIFETIME;
            radius = maxRadius * t;
            alpha = 1.0f - t;
        }

        public boolean isDead() { return age >= LIFETIME; }
        public float getPartialRadius(float partial) {
            float t = ((float)(age) + partial) / LIFETIME;
            return maxRadius * Math.min(t, 1.0f);
        }
    }

    private static class DelayedSound {
        final Vec3 center;
        final float power;
        final float normalizedPower;
        int ticksLeft;

        DelayedSound(Vec3 center, float power, float normalizedPower, int ticksLeft) {
            this.center = center;
            this.power = power;
            this.normalizedPower = normalizedPower;
            this.ticksLeft = ticksLeft;
        }
    }
}
